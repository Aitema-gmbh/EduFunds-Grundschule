import { GoogleGenAI, Type, Schema } from "@google/genai";
import { FundingProgram, MatchResult, SchoolProfile, GeneratedApplication } from "../types";

const apiKey = process.env.API_KEY || '';
const ai = new GoogleGenAI({ apiKey });

const MODEL_FAST = 'gemini-2.5-flash';
const MODEL_SMART = 'gemini-2.5-flash'; 

const matchResponseSchema: Schema = {
  type: Type.ARRAY,
  items: {
    type: Type.OBJECT,
    properties: {
      programId: { type: Type.STRING },
      score: { type: Type.NUMBER, description: "Relevance score between 0 and 100" },
      reasoning: { type: Type.STRING, description: "Short explanation why this fits (in German)" },
      tags: { 
          type: Type.ARRAY, 
          items: { type: Type.STRING },
          description: "Short tags like 'Geo-Match', 'Topic-Match', 'Social-Bonus'" 
      }
    },
    required: ["programId", "score", "reasoning", "tags"]
  }
};

const applicationResponseSchema: Schema = {
  type: Type.OBJECT,
  properties: {
    subject: { type: Type.STRING, description: "Formal subject line for the email/letter including the program name" },
    executiveSummary: { type: Type.STRING, description: "A 2-3 sentence summary of the proposal" },
    body: { type: Type.STRING, description: "The full proposal text in Markdown format" }
  },
  required: ["subject", "executiveSummary", "body"]
};

// Helper to parse German date strings and check if expired
const isProgramActive = (deadlineStr: string): boolean => {
    const today = new Date();
    const currentYear = today.getFullYear();
    
    // Case 1: "Laufend" or "Permanent" -> Always active
    if (deadlineStr.toLowerCase().includes('laufend') || deadlineStr.toLowerCase().includes('permanent')) {
        return true;
    }

    // Case 2: Explicit Date "DD.MM.YYYY"
    const dateMatch = deadlineStr.match(/(\d{2})\.(\d{2})\.(\d{4})/);
    if (dateMatch) {
        const day = parseInt(dateMatch[1]);
        const month = parseInt(dateMatch[2]) - 1; // JS months are 0-indexed
        const year = parseInt(dateMatch[3]);
        const deadlineDate = new Date(year, month, day);
        
        // If deadline is in the past (yesterday or earlier), return false
        if (deadlineDate < today) return false;
        return true;
    }

    // Case 3: Just a year check (e.g. "Herbst 2025")
    // If it explicitly mentions a past year, filter it.
    if (deadlineStr.includes((currentYear - 1).toString())) return false;

    // Default: If we can't parse it strictly, we let the AI decide/keep it
    return true;
};

export const analyzeSchoolWithGemini = async (name: string, city: string): Promise<Partial<SchoolProfile>> => {
    if (!apiKey) return {};

    // Prompt specifically targets Grundschulen
    const prompt = `
      Recherchiere die GRUNDSCHULE: "${name}" in "${city}".
      
      Ziel: Erstelle ein Profil für Förderanträge (Primarstufe).
      
      1. Finde die offizielle Website.
      2. Ermittle das Bundesland und gib den ISO-Code zurück (z.B. "DE-BY").
      3. Suche nach "Leitbild", "Schulprogramm" oder "Pädagogisches Konzept".
      4. Suche Schülerzahl (meist ca. 100-400 bei Grundschulen).
      5. Suche nach speziellen Grundschul-Profilen (z.B. "Bewegte Schule", "Montessori", "MINT-freundlich").
      
      ANTWORTE NUR MIT VALIDEM JSON (kein Markdown).
      
      Struktur:
      {
        "website": "URL",
        "state": "ISO Code (z.B. DE-BW)",
        "studentCount": Zahl,
        "teacherCount": Zahl,
        "focusAreas": ["Lesen", "Bewegung", "Musik", "MINT"],
        "missionStatement": "Text",
        "socialIndex": Zahl (1-5, schätze anhand Lage),
        "address": "Straße Hausnummer, PLZ Stadt",
        "email": "Kontakt Email",
        "awards": ["Auszeichnung 1"],
        "partners": ["Partner 1"]
      }
    `;

    try {
        const response = await ai.models.generateContent({
            model: MODEL_SMART,
            contents: prompt,
            config: {
                tools: [{ googleSearch: {} }]
            }
        });

        let text = response.text;
        if (!text) return {};
        
        if (text.includes('```json')) {
            text = text.split('```json')[1].split('```')[0];
        } else if (text.includes('```')) {
            text = text.split('```')[1].split('```')[0];
        }
        text = text.trim();
        
        const data = JSON.parse(text) as Partial<SchoolProfile>;
        
        // Defaults for Primary Schools
        if (!data.studentCount) data.studentCount = 200;
        if (!data.socialIndex) data.socialIndex = 3;
        if (!data.state) data.state = 'DE'; // Fallback
        
        return data;
    } catch (error) {
        console.error("School Analysis Error:", error);
        return { name, location: city, state: 'DE' };
    }
};

export const matchProgramsWithGemini = async (
  profile: SchoolProfile,
  programs: FundingProgram[]
): Promise<MatchResult[]> => {
  if (!apiKey) {
    return programs.map(p => ({
      programId: p.id,
      score: 50,
      reasoning: "Mock Matching (No API Key)",
      tags: ["Mock Data"]
    }));
  }

  // 1. Strict Filtering (Geo & Date) BEFORE AI
  const eligiblePrograms = programs.filter(p => {
      // Geo Check
      const regionMatch = p.region.includes('DE') || (profile.state && p.region.includes(profile.state));
      if (!regionMatch) return false;

      // Date Check
      const dateActive = isProgramActive(p.deadline);
      if (!dateActive) return false;
      
      return true;
  });

  if (eligiblePrograms.length === 0) return [];

  const todayDate = new Date().toLocaleDateString('de-DE');

  const prompt = `
    HEUTIGES DATUM: ${todayDate}
    KONTEXT: GRUNDSCHULE / PRIMARSTUFE (Klasse 1-4, Alter 6-10).

    Bewerte die Passung (0-100) für folgende Förderprogramme für diese Schule:
    
    SCHULE:
    Name: ${profile.name}
    Ort: ${profile.location} (${profile.state})
    Profil: ${profile.focusAreas.join(', ')}
    Sozialindex: ${profile.socialIndex}
    Leitbild: ${profile.missionStatement}

    PROGRAMME:
    ${JSON.stringify(eligiblePrograms.map(p => ({
        id: p.id,
        title: p.title,
        focus: p.focus,
        targetGroup: p.targetGroup,
        requirements: p.requirements
    })))}

    LOGIK:
    1. Zielgruppe: Muss für Grundschule (Klasse 1-4) passen. Wenn Programm für "Berufsvorbereitung" oder "Oberstufe" ist -> SCORE 0.
    2. Sozialindex: Hoher Index (4-5) + "Startchancen" oder "Soziale Benachteiligung" -> Score Boost.
    3. Thematisch: Wenn Schule "Bewegung" Profil hat und Programm "Schulhof" fördert -> Score 90+.
    
    TAGS:
    Erstelle kurze Tags (Max 3) wie "Ideal für Primarstufe", "Sozial-Bonus", "Thema passt".

    Return JSON Array.
  `;

  try {
    const response = await ai.models.generateContent({
      model: MODEL_FAST,
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: matchResponseSchema
      }
    });

    const text = response.text;
    if (!text) return [];
    
    const aiResults = JSON.parse(text) as MatchResult[];
    
    return aiResults;

  } catch (error) {
    console.error("Matching Error:", error);
    return [];
  }
};

export const generateApplicationDraft = async (
  profile: SchoolProfile,
  program: FundingProgram,
  projectSpecifics: string
): Promise<GeneratedApplication | null> => {
    if (!apiKey) return null;

    const prompt = `
      Rolle: Pädagogischer Experte für Grundschul-Förderung & Schulentwicklung.
      Aufgabe: Erstelle einen professionellen, pädagogisch fundierten Antragstext für: ${program.title}.
      Zielgruppe des Antragslesers: Schulamt, Stiftung oder Ministerium.
      
      KONTEXT SCHULE (GRUNDSCHULE):
      Name: ${profile.name}, ${profile.location}
      Leitbild: "${profile.missionStatement}"
      Besonderheit: Primarstufe (Kinder 6-10 Jahre).
      
      PROGRAMM:
      Geber: ${program.provider}
      Kriterien: ${program.detailedCriteria?.join(', ')}
      Einreichungsweg: ${program.submissionMethod}
      
      WICHTIG - ANLAGEN:
      Geforderte Dokumente: ${program.requiredDocuments.join(', ')}.
      
      PROJEKTIDEE:
      ${projectSpecifics}

      STRATEGIE:
      - Nutze kindgerechte, pädagogische Begrifflichkeiten (z.B. "ganzheitliches Lernen", "Basiskompetenzen", "Spielerischer Zugang", "Partizipation der Kinder").
      - Argumentiere mit dem Schulleitbild.
      - Betone die Nachhaltigkeit für die Schulentwicklung.
      - Tonalität: Professionell, engagiert, pädagogisch wertvoll.
      
      Format: JSON (subject, executiveSummary, body). Body ist Markdown.
    `;

    try {
      const response = await ai.models.generateContent({
        model: MODEL_SMART,
        contents: prompt,
        config: {
          responseMimeType: "application/json",
          responseSchema: applicationResponseSchema,
          thinkingConfig: { thinkingBudget: 2048 }
        }
      });

      const text = response.text;
      if(!text) return null;
      return JSON.parse(text) as GeneratedApplication;

    } catch (error) {
      console.error("Drafting Error:", error);
      return null;
    }
};

export const refineApplicationDraft = async (
    currentDraft: GeneratedApplication,
    instruction: string
): Promise<GeneratedApplication | null> => {
    if (!apiKey) return null;

    const prompt = `
        Rolle: Lektor für Grundschul-Förderanträge.
        
        AUFGABE:
        Überarbeite den folgenden Antragstext basierend auf dieser Instruktion: "${instruction}".
        Achte darauf, dass der pädagogische Fokus (Grundschule) erhalten bleibt.
        
        AKTUELLER TEXT:
        Betreff: ${currentDraft.subject}
        Body: ${currentDraft.body}
        
        Format: JSON (subject, executiveSummary, body).
    `;

    try {
        const response = await ai.models.generateContent({
            model: MODEL_FAST, // Fast model is enough for refinement
            contents: prompt,
            config: {
                responseMimeType: "application/json",
                responseSchema: applicationResponseSchema
            }
        });

        const text = response.text;
        if (!text) return null;
        return JSON.parse(text) as GeneratedApplication;
    } catch (error) {
        console.error("Refinement Error", error);
        return null;
    }
}

export const searchLiveFunding = async (): Promise<FundingProgram[]> => {
  if (!apiKey) return [];

  const todayYear = new Date().getFullYear();
  // Ensure we look for current and next year opportunities
  const queryContext = `Förderprogramme Grundschule Deutschland ${todayYear} ${todayYear + 1} Stiftung Bildung Sport Kultur MINT`;

  const prompt = `
    Suche nach 6-8 AKTUELLEN Förderprogrammen explizit für GRUNDSCHULEN (Primarstufe) in Deutschland.
    Suche breit: Stiftungen (z.B. "Aktion Mensch", "Software AG Stiftung", "Tribute to Bambi"), Landesprogramme und Wettbewerbe.
    
    CRITICAL: Die Deadlines müssen in der Zukunft liegen (Ende ${todayYear} oder in ${todayYear + 1}).
    
    Fülle alle Felder detailliert aus, damit sie professionell aussehen.
    
    REQUIRED JSON STRUCTURE (Array of objects):
    {
      "id": "unique-slug-string",
      "title": "Name des Programms",
      "provider": "Stiftung oder Behörde",
      "budget": "Max. Summe oder 'Sachmittel'",
      "deadline": "DD.MM.YYYY oder 'Laufend'",
      "focus": "Thema (z.B. Inklusion, Bau, Digital)",
      "description": "Kurze Beschreibung",
      "requirements": "Wer darf sich bewerben? (Muss Grundschule sein)",
      "targetGroup": "z.B. 'Klasse 1-4', 'Bildungsbenachteiligte'",
      "region": ["DE"] oder ["DE-NW"] (ISO Codes Array!),
      "fundingQuota": "z.B. '100% Förderung' oder 'Max. 5000€'",
      "detailedCriteria": ["Kriterium 1", "Kriterium 2"],
      "submissionMethod": "z.B. 'Online-Portal', 'Email'",
      "requiredDocuments": ["Dokument 1", "Dokument 2"],
      "fundingPeriod": "z.B. '12 Monate'",
      "officialLink": "URL"
    }
    
    Antworte NUR mit dem JSON Array.
  `;

  try {
    const response = await ai.models.generateContent({
      model: MODEL_SMART, // Use Smart model for better data extraction and mapping
      contents: prompt,
      config: {
        tools: [{ googleSearch: {} }]
      }
    });

    let text = response.text;
    if (!text) return [];

    if (text.includes('```json')) {
      text = text.split('```json')[1].split('```')[0];
    } else if (text.includes('```')) {
        text = text.split('```')[1].split('```')[0];
    }
    text = text.trim();

    try {
        const rawData = JSON.parse(text) as any[];
        
        // Validate and map strictly to FundingProgram interface
        const validatedPrograms: FundingProgram[] = rawData.map((item, index) => ({
            id: item.id || `live-gen-${Date.now()}-${index}`,
            title: item.title || 'Unbekanntes Programm',
            provider: item.provider || 'Unbekannt',
            budget: item.budget || 'Auf Anfrage',
            deadline: item.deadline || 'Unbekannt',
            focus: item.focus || 'Allgemein',
            description: item.description || '',
            requirements: item.requirements || '',
            region: Array.isArray(item.region) ? item.region : ['DE'],
            targetGroup: item.targetGroup || 'Grundschule',
            fundingQuota: item.fundingQuota || 'Varies',
            detailedCriteria: Array.isArray(item.detailedCriteria) ? item.detailedCriteria : [],
            submissionMethod: item.submissionMethod || 'Siehe Website',
            requiredDocuments: Array.isArray(item.requiredDocuments) ? item.requiredDocuments : [],
            fundingPeriod: item.fundingPeriod || '1 Jahr',
            officialLink: item.officialLink
        }));

        return validatedPrograms;
    } catch (e) {
        console.error("JSON Parse Error on Live Search", e);
        return [];
    }
  } catch (error) {
    console.error("Live Search Error:", error);
    return [];
  }
};